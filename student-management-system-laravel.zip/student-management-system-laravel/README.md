# Student Management System - Laravel CRUD

Simple Laravel CRUD web application for managing students.

## Features
- Add Student
- Edit Student
- Delete Student
- View Students
- Search Table

## Tech Stack
- Laravel
- PHP
- Bootstrap
- MySQL
- jQuery
